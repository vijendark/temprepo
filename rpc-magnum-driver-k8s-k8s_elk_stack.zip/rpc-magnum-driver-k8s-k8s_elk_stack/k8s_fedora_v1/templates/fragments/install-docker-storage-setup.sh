#!/bin/bash -x
systemctl stop docker
rm -rf /var/lib/docker/
systemctl enable docker-storage-setup
