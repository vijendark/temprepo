#!/bin/sh

. /etc/sysconfig/heat-params

echo "configuring kubernetes (minion)"

CA_CERT_DATA=$(base64 -w 0 /srv/kubernetes/ca.crt)
CLIENT_CERT_DATA=$(base64 -w 0 /srv/kubernetes/client.crt)
CLIENT_KEY_DATA=$(base64 -w 0 /srv/kubernetes/client.key)

HOSTNAME=$(hostname)
KUBE_API_URL=https://$KUBE_MASTER_IP:$KUBE_API_PORT

cat > /etc/kubernetes/kubelet.conf <<EOF
apiVersion: v1
clusters:
- cluster:
    certificate-authority-data: $CA_CERT_DATA
    server: $KUBE_API_URL
  name: kubernetes
contexts:
- context:
    cluster: kubernetes
    user: kubelet-$HOSTNAME
  name: kubelet-$HOSTNAME@kubernetes
current-context: kubelet-$HOSTNAME@kubernetes
kind: Config
preferences: {}
users:
- name: kubelet-$HOSTNAME
  user:
    client-certificate-data: $CLIENT_CERT_DATA
    client-key-data: $CLIENT_KEY_DATA
EOF

mkdir -p /etc/systemd/system/kubelet.service.d

cat > /etc/systemd/system/kubelet.service <<EOF
[Unit]
Description=Kubernetes Kubelet Server
Documentation=https://github.com/kubernetes/kubernetes
Requires=docker.service
After=docker.service

[Service]
ExecStart=/usr/bin/kubelet
Restart=always
StartLimitInterval=0
RestartSec=10

[Install]
WantedBy=multi-user.target
EOF

cat > /etc/systemd/system/kubelet.service.d/10-kubeadm.conf <<EOF
[Service]
Environment="KUBELET_KUBECONFIG_ARGS=--kubeconfig=/etc/kubernetes/kubelet.conf --require-kubeconfig=true"
Environment="KUBELET_SYSTEM_PODS_ARGS=--pod-manifest-path=/etc/kubernetes/manifests --allow-privileged=true"
Environment="KUBELET_NETWORK_ARGS="
Environment="KUBELET_DNS_ARGS="
Environment="KUBELET_EXTRA_ARGS=--v=4 --hostname-override=$KUBE_NODE_IP"
ExecStart=
ExecStart=/usr/bin/kubelet \$KUBELET_KUBECONFIG_ARGS \$KUBELET_SYSTEM_PODS_ARGS \$KUBELET_NETWORK_ARGS \$KUBELET_DNS_ARGS \$KUBELET_EXTRA_ARGS
EOF
