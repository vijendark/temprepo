#!/bin/sh -x
mkdir -p /etc/kubernetes/pki

cp /srv/kubernetes/ca.crt \
   /srv/kubernetes/server.crt \
   /srv/kubernetes/server.key \
   /etc/kubernetes/pki/

touch /etc/kubernetes/pki/tokens.csv
chmod 600 /etc/kubernetes/pki/tokens.csv

CA_CERT_DATA=$(base64 -w 0 /etc/kubernetes/pki/ca.crt)
SERVER_CERT_DATA=$(base64 -w 0 /etc/kubernetes/pki/server.crt)
SERVER_KEY_DATA=$(base64 -w 0 /etc/kubernetes/pki/server.key)

sed -i '
    /^\s*certificate-authority-data:/ s|:.*|: '"$CA_CERT_DATA"'|
    /^\s*client-certificate-data:/ s|:.*|: '"$SERVER_CERT_DATA"'|
    /^\s*client-key-data:/ s|:.*|: '"$SERVER_KEY_DATA"'|
' /etc/kubernetes/admin.conf

sed -i '
    /^\s*certificate-authority-data:/ s|:.*|: '"$CA_CERT_DATA"'|
    /^\s*client-certificate-data:/ s|:.*|: '"$SERVER_CERT_DATA"'|
    /^\s*client-key-data:/ s|:.*|: '"$SERVER_KEY_DATA"'|
' /etc/kubernetes/kubelet.conf
