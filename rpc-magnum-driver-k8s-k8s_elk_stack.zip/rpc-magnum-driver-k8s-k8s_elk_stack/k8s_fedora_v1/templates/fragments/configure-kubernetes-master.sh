#!/bin/sh

. /etc/sysconfig/heat-params

echo "configuring kubernetes (master)"

mkdir -p /etc/kubernetes/manifests

cat > /etc/kubernetes/admin.conf << EOF
apiVersion: v1
clusters:
- cluster:
    certificate-authority-data: DATA
    server: https://$KUBE_NODE_IP:$KUBE_API_PORT
  name: kubernetes
contexts:
- context:
    cluster: kubernetes
    user: admin
  name: admin@kubernetes
- context:
    cluster: kubernetes
    user: kubelet
  name: kubelet@kubernetes
current-context: admin@kubernetes
kind: Config
preferences: {}
users:
- name: admin
  user:
    client-certificate-data: DATA
    client-key-data: DATA
- name: kubelet
  user:
    client-certificate-data: DATA
    client-key-data: DATA
EOF

chmod 600 /etc/kubernetes/admin.conf
cp /etc/kubernetes/admin.conf /etc/kubernetes/kubelet.conf

cat > /etc/kubernetes/manifests/kube-apiserver.json << EOF
{
  "kind": "Pod",
  "apiVersion": "v1",
  "metadata": {
    "name": "kube-apiserver",
    "namespace": "kube-system",
    "creationTimestamp": null,
    "labels": {
      "component": "kube-apiserver",
      "tier": "control-plane"
    }
  },
  "spec": {
    "volumes": [
      {
        "name": "certs",
        "hostPath": {
          "path": "/etc/ssl/certs"
        }
      },
      {
        "name": "pki",
        "hostPath": {
          "path": "/etc/kubernetes"
        }
      }
    ],
    "containers": [
      {
        "name": "kube-apiserver",
        "image": "gcr.io/google_containers/kube-apiserver-amd64:v1.4.4",
        "command": [
          "kube-apiserver",
          "--v=2",
          "--insecure-bind-address=127.0.0.1",
          "--admission-control=NamespaceLifecycle,LimitRanger,ServiceAccount,PersistentVolumeLabel,DefaultStorageClass,ResourceQuota",
          "--service-cluster-ip-range=$PORTAL_NETWORK_CIDR",
          "--service-account-key-file=/etc/kubernetes/pki/service_account_key.pub",
          "--client-ca-file=/etc/kubernetes/pki/ca.crt",
          "--tls-cert-file=/etc/kubernetes/pki/server.crt",
          "--tls-private-key-file=/etc/kubernetes/pki/server.key",
          "--token-auth-file=/etc/kubernetes/pki/tokens.csv",
          "--secure-port=$KUBE_API_PORT",
          "--allow-privileged",
          "--advertise-address=$KUBE_NODE_IP",
          "--etcd-servers=http://127.0.0.1:2379"
        ],
        "resources": {
          "requests": {
            "cpu": "250m"
          }
        },
        "volumeMounts": [
          {
            "name": "certs",
            "mountPath": "/etc/ssl/certs"
          },
          {
            "name": "pki",
            "readOnly": true,
            "mountPath": "/etc/kubernetes/"
          }
        ],
        "livenessProbe": {
          "httpGet": {
            "path": "/healthz",
            "port": 8080,
            "host": "127.0.0.1"
          },
          "initialDelaySeconds": 15,
          "timeoutSeconds": 15,
          "failureThreshold": 8
        }
      }
    ],
    "hostNetwork": true
  },
  "status": {}
}
EOF

cat > /etc/kubernetes/manifests/kube-controller-manager.json << EOF
{
  "kind": "Pod",
  "apiVersion": "v1",
  "metadata": {
    "name": "kube-controller-manager",
    "namespace": "kube-system",
    "creationTimestamp": null,
    "labels": {
      "component": "kube-controller-manager",
      "tier": "control-plane"
    }
  },
  "spec": {
    "volumes": [
      {
        "name": "certs",
        "hostPath": {
          "path": "/etc/ssl/certs"
        }
      },
      {
        "name": "pki",
        "hostPath": {
          "path": "/etc/kubernetes"
        }
      }
    ],
    "containers": [
      {
        "name": "kube-controller-manager",
        "image": "gcr.io/google_containers/kube-controller-manager-amd64:v1.4.4",
        "command": [
          "kube-controller-manager",
          "--v=2",
          "--address=127.0.0.1",
          "--leader-elect",
          "--master=127.0.0.1:8080",
          "--cluster-name=kubernetes",
          "--root-ca-file=/etc/kubernetes/pki/ca.crt",
          "--service-account-private-key-file=/etc/kubernetes/pki/service_account_key",
          "--insecure-experimental-approve-all-kubelet-csrs-for-group=system:kubelet-bootstrap",
          "--allocate-node-cidrs=true",
          "--cluster-cidr=$FLANNEL_NETWORK_CIDR"
        ],
        "resources": {
          "requests": {
            "cpu": "200m"
          }
        },
        "volumeMounts": [
          {
            "name": "certs",
            "mountPath": "/etc/ssl/certs"
          },
          {
            "name": "pki",
            "readOnly": true,
            "mountPath": "/etc/kubernetes/"
          }
        ],
        "livenessProbe": {
          "httpGet": {
            "path": "/healthz",
            "port": 10252,
            "host": "127.0.0.1"
          },
          "initialDelaySeconds": 15,
          "timeoutSeconds": 15,
          "failureThreshold": 8
        }
      }
    ],
    "hostNetwork": true
  },
  "status": {}
}
EOF

cat > /etc/kubernetes/manifests/kube-scheduler.json << EOF
{
  "kind": "Pod",
  "apiVersion": "v1",
  "metadata": {
    "name": "kube-scheduler",
    "namespace": "kube-system",
    "creationTimestamp": null,
    "labels": {
      "component": "kube-scheduler",
      "tier": "control-plane"
    }
  },
  "spec": {
    "containers": [
      {
        "name": "kube-scheduler",
        "image": "gcr.io/google_containers/kube-scheduler-amd64:v1.4.4",
        "command": [
          "kube-scheduler",
          "--v=2",
          "--address=127.0.0.1",
          "--leader-elect",
          "--master=127.0.0.1:8080"
        ],
        "resources": {
          "requests": {
            "cpu": "100m"
          }
        },
        "livenessProbe": {
          "httpGet": {
            "path": "/healthz",
            "port": 10251,
            "host": "127.0.0.1"
          },
          "initialDelaySeconds": 15,
          "timeoutSeconds": 15,
          "failureThreshold": 8
        }
      }
    ],
    "hostNetwork": true
  },
  "status": {}
}
EOF

mkdir -p /etc/systemd/system/kubelet.service.d

cat > /etc/systemd/system/kubelet.service << EOF
[Unit]
Description=Kubernetes Kubelet Server
Documentation=https://github.com/kubernetes/kubernetes
# TODO: Use these? Or let kubeadm soft-dep handle it?
Requires=docker.service
After=docker.service

[Service]
ExecStart=/usr/bin/kubelet
Restart=always
StartLimitInterval=0
RestartSec=10

[Install]
WantedBy=multi-user.target
EOF

# Create a valid IP within the portal network CIDR for the cluster's
# DNS server. For example, `10.254.0.0/16` -> `10.254.0.10`. The host
# ID of 10 was selected to match 10-kubeadm.conf (the default service
# CIDR is 10.96.0.0/12 and default cluster DNS IP 10.96.0.10).
CLUSTER_DNS=$(echo $PORTAL_NETWORK_CIDR | sed 's/[^\.]*$//')10

cat > /etc/systemd/system/kubelet.service.d/10-kubeadm.conf << EOF
[Service]
Environment="KUBELET_KUBECONFIG_ARGS=--kubeconfig=/etc/kubernetes/kubelet.conf --require-kubeconfig=true"
Environment="KUBELET_SYSTEM_PODS_ARGS=--pod-manifest-path=/etc/kubernetes/manifests --allow-privileged=true"
Environment="KUBELET_NETWORK_ARGS="
Environment="KUBELET_DNS_ARGS=--cluster-dns=$CLUSTER_DNS --cluster-domain=cluster.local"
Environment="KUBELET_EXTRA_ARGS=--v=4 --hostname-override=$KUBE_NODE_IP --node-labels master=true,es_node=true"
ExecStart=
ExecStart=/usr/bin/kubelet \$KUBELET_KUBECONFIG_ARGS \$KUBELET_SYSTEM_PODS_ARGS \$KUBELET_NETWORK_ARGS \$KUBELET_DNS_ARGS \$KUBELET_EXTRA_ARGS
EOF
