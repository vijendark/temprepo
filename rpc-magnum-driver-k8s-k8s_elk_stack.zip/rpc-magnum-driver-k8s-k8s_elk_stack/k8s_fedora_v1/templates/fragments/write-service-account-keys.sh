#!/bin/bash
KEY_DIR=/etc/kubernetes/pki/
mkdir -p $KEY_DIR

pushd $KEY_DIR

cat > temp_key << EOF
SERVICE_ACCOUNT_KEY_DATA
EOF

openssl rsa -in temp_key -out service_account_key
openssl rsa -in temp_key -pubout -out service_account_key.pub
rm temp_key

popd
